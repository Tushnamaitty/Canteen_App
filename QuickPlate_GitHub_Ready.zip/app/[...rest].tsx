
import { Redirect } from 'expo-router';

export default function CatchAll() {
    return <Redirect href="/" />;
}
